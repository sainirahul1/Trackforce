const mongoose = require('mongoose');

const tenantSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  domain: {
    type: String,
    unique: true,
    sparse: true,
  },
  industry: {
    type: String,
    default: 'Technology',
  },
  onboardingStatus: {
    type: String,
    enum: ['pending', 'active', 'suspended'],
    default: 'active',
  },
  subscription: {
    planId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subscription',
    },
    plan: {
      type: String, // Keeping this for backwards compatibility/display name caching
      default: 'basic',
    },
    status: {
      type: String,
      enum: ['active', 'past_due', 'canceled'],
      default: 'active',
    },
    expiry: Date,
    employeeLimit: Number,
  },
  settings: {
    logo: String,
    primaryColor: String,
    trackingInterval: {
      type: Number,
      default: 15, // seconds
    },
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
}, { timestamps: true, collection: 'superadmin.tenants' });

module.exports = mongoose.model('Tenant', tenantSchema);
